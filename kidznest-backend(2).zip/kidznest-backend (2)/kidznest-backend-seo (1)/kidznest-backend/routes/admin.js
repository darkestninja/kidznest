'use strict';
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const { pipeline, Transform } = require('stream');
const { promisify } = require('util');
const mediaLib = require('../lib/media');
const express = require('express');
const config = require('../lib/config');
const dbm = require('../lib/db');
const limits = require('../lib/limits');
const orders = require('../lib/orders');
const { getStripe } = require('../lib/stripe');
const U = require('../lib/util');

// ------------------------------------------------------------------ auth
const digest = s => crypto.createHash('sha256').update(String(s)).digest();
const same = (a, b) => crypto.timingSafeEqual(digest(a), digest(b));

function auth(req, res, next) {
  if (!config.admin.password) return res.status(503).type('text').send('Admin is disabled: set ADMIN_PASSWORD in the server environment.');
  const h = req.headers.authorization || '';
  const m = /^Basic (.+)$/.exec(h);
  let ok = false;
  if (m) {
    const [u, ...rest] = Buffer.from(m[1], 'base64').toString('utf8').split(':');
    ok = same(u, config.admin.user) & same(rest.join(':'), config.admin.password);
  }
  if (!ok) {
    res.set('WWW-Authenticate', 'Basic realm="Kidz Nest Admin", charset="UTF-8"');
    return res.status(401).type('text').send('Authentication required');
  }
  // Browsers attach Basic credentials automatically, so state-changing calls must prove they came from our own page.
  if (!['GET', 'HEAD'].includes(req.method) && req.headers['x-kn-admin'] !== '1') {
    return res.status(403).json({ error: 'Missing admin header.' });
  }
  res.set('Cache-Control', 'no-store');
  next();
}

const router = express.Router();
router.use(limits.adminAuth, auth);

const db = () => dbm.get();
const pounds = c => c / 100;

// ------------------------------------------------------------------ dashboard numbers
router.get('/stats', (req, res) => {
  const today = U.todayLondonISO();
  const q = (sql, ...a) => db().prepare(sql).get(...a);
  res.json({
    today,
    bookingsToday: q(`SELECT COUNT(*) n, COALESCE(SUM(people),0) p FROM bookings WHERE date_iso=? AND status='confirmed'`, today),
    upcoming: q(`SELECT COUNT(*) n, COALESCE(SUM(total_paid),0)/100.0 revenue FROM bookings WHERE date_iso>=? AND status='confirmed'`, today),
    revenueAll: q(`SELECT COALESCE(SUM(total_paid-refunded),0)/100.0 v FROM bookings WHERE status!='cancelled' OR refunded<total_paid`).v,
    members: q('SELECT COUNT(*) n FROM members').n,
    pendingReviews: q('SELECT COUNT(*) n FROM reviews WHERE approved=0').n,
    stripeConfigured: !!config.stripe.secretKey,
    chatConfigured: !!config.chat.apiKey,
    mailConfigured: !!config.mail.host
  });
});

// ------------------------------------------------------------------ bookings
function bookingQuery(query) {
  const where = [], args = [];
  if (query.status && ['confirmed', 'cancelled'].includes(query.status)) { where.push('status=?'); args.push(query.status); }
  if (/^\d{4}-\d{2}-\d{2}$/.test(query.from || '')) { where.push('date_iso>=?'); args.push(query.from); }
  if (/^\d{4}-\d{2}-\d{2}$/.test(query.to || '')) { where.push('date_iso<=?'); args.push(query.to); }
  if (query.q) {
    const like = '%' + String(query.q).slice(0, 60).replace(/[%_]/g, '') + '%';
    where.push('(customer_name LIKE ? OR customer_email LIKE ? OR customer_phone LIKE ? OR session LIKE ?)');
    args.push(like, like, like, like);
  }
  return db().prepare(`SELECT * FROM bookings ${where.length ? 'WHERE ' + where.join(' AND ') : ''} ORDER BY date_iso DESC, time_label, id DESC LIMIT 1000`).all(...args);
}

const adminBooking = b => ({
  id: b.id, session: b.session, date_iso: b.date_iso, date: b.date_label, time: b.time_label,
  children: b.flat ? `15 incl. +${b.qty}` : b.qty, people: b.people,
  extras: JSON.parse(b.extras_json || '[]'),
  subtotal: pounds(b.subtotal), promo_discount: pounds(b.promo_discount), member_discount: pounds(b.discount),
  reward_used: pounds(b.reward_used), total_paid: pounds(b.total_paid), refunded: pounds(b.refunded),
  status: b.status, name: b.customer_name, email: b.customer_email, phone: b.customer_phone,
  member_id: b.member_id, promo_code: b.promo_code, note: b.admin_note, created_at: b.created_at
});

router.get('/bookings', (req, res) => res.json(bookingQuery(req.query).map(adminBooking)));

router.get('/bookings.csv', (req, res) => {
  const cols = ['id', 'created_at', 'date', 'time', 'session', 'children', 'people', 'total_paid', 'refunded', 'status', 'name', 'email', 'phone', 'member_id', 'promo_code', 'note'];
  // Neutralise spreadsheet formula injection (=, +, -, @ at the start of a cell).
  const cell = v => { let s = String(v == null ? '' : v); if (/^[=+\-@\t\r]/.test(s)) s = "'" + s; return '"' + s.replace(/"/g, '""') + '"'; };
  const rows = bookingQuery(req.query).map(adminBooking);
  res.type('text/csv').set('Content-Disposition', 'attachment; filename="kidznest-bookings.csv"');
  res.send([cols.join(','), ...rows.map(r => cols.map(c => cell(r[c])).join(','))].join('\n'));
});

// Cancel a booking (frees its seats). Optionally refund the card payment through Stripe.
router.post('/bookings/:id/cancel', U.asyncH(async (req, res) => {
  const id = parseInt(req.params.id, 10);
  const b = db().prepare('SELECT * FROM bookings WHERE id=?').get(id);
  if (!b) throw new U.HttpError(404, 'Booking not found.');
  if (b.status === 'cancelled') throw new U.HttpError(409, 'That booking is already cancelled.');
  const wantRefund = !!(req.body && req.body.refund);
  const note = U.clean(req.body && req.body.note, 300);
  let refunded = 0;

  if (wantRefund && b.total_paid > 0) {
    const co = db().prepare('SELECT payment_intent FROM checkouts WHERE id=?').get(b.checkout_id);
    if (!co || !co.payment_intent) throw new U.HttpError(409, 'This payment has no card charge to refund.');
    try {
      await getStripe().refunds.create({ payment_intent: co.payment_intent, amount: b.total_paid, metadata: { booking_id: String(b.id) } },
        { idempotencyKey: `kn-refund-booking-${b.id}` });
    } catch (e) {
      console.error('[refund] failed:', e.message);
      throw new U.HttpError(502, 'Stripe could not process the refund: ' + e.message);
    }
    refunded = b.total_paid;
  }

  db().transaction(() => {
    db().prepare(`UPDATE bookings SET status='cancelled', refunded=?, admin_note=? WHERE id=? AND status!='cancelled'`).run(refunded, note, id);
    if (refunded > 0 && b.member_id) {
      // Reverse the reward story: give back any reward spent, take back any reward earned (never below zero).
      db().prepare('UPDATE members SET reward = MAX(0, reward + ? - ?) WHERE id=?').run(b.reward_used, b.reward_earned, b.member_id);
    }
  })();
  res.json({ ok: true, refunded: pounds(refunded) });
}));

router.post('/bookings/:id/note', (req, res) => {
  db().prepare('UPDATE bookings SET admin_note=? WHERE id=?').run(U.clean(req.body && req.body.note, 300), parseInt(req.params.id, 10));
  res.json({ ok: true });
});

// ------------------------------------------------------------------ members
router.get('/members', (req, res) => {
  res.json(db().prepare('SELECT * FROM members ORDER BY created_at DESC LIMIT 2000').all()
    .map(m => ({ ...m, reward: pounds(m.reward) })));
});

router.post('/members/:id/reward', (req, res) => {
  const delta = U.toCents(req.body && req.body.amount);
  if (!Number.isFinite(delta) || delta === 0 || Math.abs(delta) > 50000) throw new U.HttpError(400, 'Enter an amount between -£500 and £500.');
  const r = db().prepare('UPDATE members SET reward = MAX(0, reward + ?) WHERE id=?').run(delta, req.params.id);
  if (!r.changes) throw new U.HttpError(404, 'Member not found.');
  res.json({ ok: true, reward: pounds(db().prepare('SELECT reward FROM members WHERE id=?').get(req.params.id).reward) });
});

router.delete('/members/:id', (req, res) => {
  const r = db().prepare('DELETE FROM members WHERE id=?').run(req.params.id);
  if (!r.changes) throw new U.HttpError(404, 'Member not found.');
  res.json({ ok: true });
});

// ------------------------------------------------------------------ reviews
router.get('/reviews', (req, res) => {
  const f = req.query.filter === 'approved' ? 'WHERE approved=1' : req.query.filter === 'pending' ? 'WHERE approved=0' : '';
  res.json(db().prepare(`SELECT * FROM reviews ${f} ORDER BY id DESC LIMIT 500`).all());
});
router.post('/reviews/:id/approve', (req, res) => {
  db().prepare('UPDATE reviews SET approved=? WHERE id=?').run(req.body && req.body.approved === false ? 0 : 1, parseInt(req.params.id, 10));
  res.json({ ok: true });
});
router.delete('/reviews/:id', (req, res) => {
  db().prepare('DELETE FROM reviews WHERE id=?').run(parseInt(req.params.id, 10));
  res.json({ ok: true });
});

// ------------------------------------------------------------------ blocked slots
router.get('/blocks', (req, res) => {
  res.json(db().prepare('SELECT * FROM blocked_slots WHERE date_iso>=? ORDER BY date_iso, time_label').all(U.todayLondonISO()));
});
router.post('/blocks', (req, res) => {
  const b = req.body || {};
  if (!/^\d{4}-\d{2}-\d{2}$/.test(b.date || '')) throw new U.HttpError(400, 'Pick a date.');
  let label = null;
  if (b.time) {
    const dow = new Date(b.date + 'T00:00:00Z').getUTCDay();
    const t = U.slotFromLabel(b.time, dow);
    if (!t) throw new U.HttpError(400, 'That time is not a bookable slot on that day.');
    label = U.fmtSlot(t);
  }
  const r = db().prepare('INSERT INTO blocked_slots (date_iso,time_label,reason) VALUES (?,?,?)').run(b.date, label, U.clean(b.reason, 200));
  res.status(201).json({ id: r.lastInsertRowid });
});
router.delete('/blocks/:id', (req, res) => {
  db().prepare('DELETE FROM blocked_slots WHERE id=?').run(parseInt(req.params.id, 10));
  res.json({ ok: true });
});

// Slots for a date (used by the "block a slot" picker)
router.get('/slots', (req, res) => {
  const dow = new Date((req.query.date || '') + 'T00:00:00Z').getUTCDay();
  res.json((config.business.slotsByDay[dow] || []).map(U.fmtSlot));
});

// ------------------------------------------------------------------ photos & videos (owner only)
// The browser sends the raw file as the request body (no multipart) with the title in a header.
router.post('/media', U.asyncH(async (req, res) => {
  const title = U.clean(decodeURIComponent(String(req.headers['x-title'] || '')), 100);
  const description = U.clean(decodeURIComponent(String(req.headers['x-description'] || '')), 300);
  if (!title) throw new U.HttpError(400, 'Please add a title.');
  const declared = String(req.headers['content-type'] || '');
  const wantsVideo = declared.startsWith('video/');
  if (!wantsVideo && !declared.startsWith('image/')) throw new U.HttpError(415, 'Please choose a photo or a video file.');
  const limit = wantsVideo ? mediaLib.MAX_VIDEO : mediaLib.MAX_IMAGE;
  const len = Number(req.headers['content-length']);
  if (!len) throw new U.HttpError(411, 'Empty upload.');
  if (len > limit) throw new U.HttpError(413, `That file is too big (max ${limit / 1048576} MB).`);

  mediaLib.ensureDir();
  const tmp = path.join(mediaLib.dir(), crypto.randomUUID() + '.part');
  let seen = 0;
  const cap = new Transform({ transform(chunk, enc, cb) {
    seen += chunk.length;
    if (seen > limit) return cb(new U.HttpError(413, `That file is too big (max ${limit / 1048576} MB).`));
    cb(null, chunk);
  } });
  try {
    await promisify(pipeline)(req, cap, fs.createWriteStream(tmp));
    const fd = fs.openSync(tmp, 'r'); const head = Buffer.alloc(16); fs.readSync(fd, head, 0, 16, 0); fs.closeSync(fd);
    const kind = mediaLib.detect(head);
    if (!kind || (kind.type === 'video') !== wantsVideo) throw new U.HttpError(400, wantsVideo ? 'That is not a supported video (use MP4, MOV or WebM).' : 'That is not a supported photo (use JPG, PNG, WebP or GIF).');
    const filename = crypto.randomUUID() + '.' + kind.ext;
    fs.renameSync(tmp, path.join(mediaLib.dir(), filename));
    const r = db().prepare('INSERT INTO media (type,title,description,filename,mime,size) VALUES (?,?,?,?,?,?)').run(kind.type, title, description, filename, kind.mime, seen);
    res.status(201).json({ id: r.lastInsertRowid, url: '/media/' + filename });
  } catch (e) {
    fs.rm(tmp, { force: true }, () => {});
    throw e;
  }
}));

router.get('/media', (req, res) => {
  res.json(db().prepare('SELECT * FROM media ORDER BY id DESC LIMIT 500').all().map(m => ({ ...m, url: '/media/' + m.filename })));
});

router.delete('/media/:id', (req, res) => {
  const id = parseInt(req.params.id, 10);
  const m = db().prepare('SELECT filename FROM media WHERE id=?').get(id);
  if (!m) throw new U.HttpError(404, 'Not found.');
  db().prepare('DELETE FROM media WHERE id=?').run(id);
  fs.rm(path.join(mediaLib.dir(), m.filename), { force: true }, () => {});
  res.json({ ok: true });
});

module.exports = { router, auth };
