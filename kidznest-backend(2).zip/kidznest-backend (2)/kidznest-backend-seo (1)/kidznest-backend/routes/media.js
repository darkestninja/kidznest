'use strict';
const router = require('express').Router();
const dbm = require('../lib/db');

// Public, read-only list of the photos/videos the owner has uploaded (newest first).
router.get('/', (req, res) => {
  res.set('Cache-Control', 'public, max-age=60');
  const rows = dbm.get().prepare('SELECT id,type,title,description,filename,created_at FROM media ORDER BY id DESC LIMIT 300').all();
  res.json(rows.map(r => ({ id: r.id, type: r.type, title: r.title, description: r.description, url: '/media/' + r.filename, created_at: r.created_at })));
});

module.exports = router;
