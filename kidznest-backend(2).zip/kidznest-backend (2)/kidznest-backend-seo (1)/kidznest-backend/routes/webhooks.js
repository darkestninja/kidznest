'use strict';
const express = require('express');
const router = express.Router();
const config = require('../lib/config');
const dbm = require('../lib/db');
const orders = require('../lib/orders');
const { getStripe } = require('../lib/stripe');

// Stripe needs the *raw* body to verify the signature, so this router is mounted before express.json().
router.post('/stripe', express.raw({ type: 'application/json', limit: '1mb' }), async (req, res) => {
  let event;
  try {
    event = getStripe().webhooks.constructEvent(req.body, req.headers['stripe-signature'], config.stripe.webhookSecret);
  } catch (e) {
    console.warn('[webhook] bad signature:', e.message);
    return res.status(400).send('Bad signature');
  }
  const db = dbm.get();
  try {
    const obj = event.data.object;
    const checkoutId = obj && (obj.client_reference_id || (obj.metadata && obj.metadata.checkout_id));
    switch (event.type) {
      case 'checkout.session.completed':
      case 'checkout.session.async_payment_succeeded':
        if (obj.payment_status === 'paid' && checkoutId) await orders.fulfil(checkoutId, obj.payment_intent);
        break;
      case 'checkout.session.expired':
      case 'checkout.session.async_payment_failed':
        if (checkoutId) orders.release(checkoutId);
        break;
      default: break;
    }
    db.prepare('INSERT OR IGNORE INTO stripe_events (id,type) VALUES (?,?)').run(event.id, event.type);
    res.json({ received: true });
  } catch (e) {
    console.error('[webhook] handler failed:', e);
    res.status(500).send('Handler error'); // Stripe will retry
  }
});

module.exports = router;
