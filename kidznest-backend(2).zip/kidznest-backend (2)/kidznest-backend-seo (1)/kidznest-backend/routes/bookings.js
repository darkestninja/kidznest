'use strict';
const router = require('express').Router();
const dbm = require('../lib/db');
const orders = require('../lib/orders');
const limits = require('../lib/limits');
const { normEmail, isEmail, HttpError } = require('../lib/util');

// GET /api/bookings/by-email/:email -> [booking...]  (newest first)
router.get('/by-email/:email', limits.lookup, (req, res) => {
  const email = normEmail(decodeURIComponent(req.params.email));
  if (!isEmail(email)) throw new HttpError(400, 'Please enter a valid email address.');
  const rows = dbm.get().prepare('SELECT * FROM bookings WHERE customer_email=? ORDER BY date_iso DESC, id DESC LIMIT 100').all(email);
  res.set('Cache-Control', 'no-store');
  res.json(rows.map(r => orders.mapBooking(r)));
});

module.exports = router;
