'use strict';
const router = require('express').Router();
const dbm = require('../lib/db');
const limits = require('../lib/limits');
const mailer = require('../lib/mailer');
const { clean, normEmail, isEmail, isPhone, memberId, maskPhone, HttpError } = require('../lib/util');

// Public view of a member. The phone number is masked because membership is looked up by email alone.
const view = m => ({
  id: m.id, name: m.name, email: m.email, phone: maskPhone(m.phone), location: m.location,
  reward: m.reward / 100, created_at: m.created_at
});

router.get('/lookup', limits.lookup, (req, res) => {
  const email = normEmail(req.query.email);
  if (!isEmail(email)) throw new HttpError(400, 'Please enter a valid email address.');
  const m = dbm.get().prepare('SELECT * FROM members WHERE email=?').get(email);
  res.set('Cache-Control', 'no-store');
  if (!m) throw new HttpError(404, 'No membership found for that email.');
  res.json(view(m));
});

router.post('/join', limits.join, (req, res) => {
  const b = req.body || {};
  const name = clean(b.name, 100), location = clean(b.location, 100), phone = clean(b.phone, 25), email = normEmail(b.email);
  if (name.length < 2 || location.length < 2) throw new HttpError(400, 'Please fill in your name and location.');
  if (!isPhone(phone)) throw new HttpError(400, 'Please enter a valid phone number.');
  if (!isEmail(email)) throw new HttpError(400, 'Please enter a valid email address.');
  const db = dbm.get();
  const existing = db.prepare('SELECT * FROM members WHERE email=?').get(email);
  let m, returning = false;
  if (existing) {
    returning = true;
    db.prepare(`UPDATE members SET name=?, phone=?, location=?, updated_at=strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE id=?`).run(name, phone, location, existing.id);
    m = db.prepare('SELECT * FROM members WHERE id=?').get(existing.id);
  } else {
    let id; do { id = memberId(); } while (db.prepare('SELECT 1 FROM members WHERE id=?').get(id));
    db.prepare('INSERT INTO members (id,name,email,phone,location) VALUES (?,?,?,?,?)').run(id, name, email, phone, location);
    m = db.prepare('SELECT * FROM members WHERE id=?').get(id);
  }
  mailer.sendMemberEmail(m, returning).catch(() => {});
  res.status(returning ? 200 : 201).json({ ...view(m), returning });
});

module.exports = router;
