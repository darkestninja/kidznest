'use strict';
const router = require('express').Router();
const dbm = require('../lib/db');
const limits = require('../lib/limits');
const mailer = require('../lib/mailer');
const { clean, HttpError } = require('../lib/util');

// Approved reviews only, newest first (the website prepends them above its example reviews).
router.get('/', (req, res) => {
  res.set('Cache-Control', 'public, max-age=60');
  res.json(dbm.get().prepare('SELECT id,name,rating,text FROM reviews WHERE approved=1 ORDER BY id DESC LIMIT 50').all());
});

router.post('/', limits.review, (req, res) => {
  const b = req.body || {};
  const name = clean(b.name, 60), text = clean(b.text, 1500), rating = Number(b.rating);
  if (!name) throw new HttpError(400, 'Please enter your name.');
  if (text.length < 5) throw new HttpError(400, 'Please write a short review.');
  if (!Number.isInteger(rating) || rating < 1 || rating > 5) throw new HttpError(400, 'Please choose a star rating.');
  const r = dbm.get().prepare('INSERT INTO reviews (name,rating,text) VALUES (?,?,?)').run(name, rating, text);
  mailer.sendReviewEmail({ name, rating, text }).catch(() => {});
  res.status(201).json({ id: r.lastInsertRowid, pending: true });
});

module.exports = router;
