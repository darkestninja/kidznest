'use strict';
const router = require('express').Router();
const orders = require('../lib/orders');

// GET /api/availability?date=July 20, 2026  ->  {"booked":{"11:30 AM":12,"1:00 PM":30}}
router.get('/', (req, res) => {
  res.set('Cache-Control', 'no-store');
  res.json(orders.availability(req.query.date));
});

module.exports = router;
