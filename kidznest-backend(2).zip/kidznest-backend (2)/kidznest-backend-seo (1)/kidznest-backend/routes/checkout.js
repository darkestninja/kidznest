'use strict';
const router = require('express').Router();
const orders = require('../lib/orders');
const limits = require('../lib/limits');
const { asyncH } = require('../lib/util');

// POST /api/checkout/create-session  -> {url}  (website then redirects the browser to Stripe)
router.post('/create-session', limits.checkout, asyncH(async (req, res) => {
  res.json(await orders.createCheckout(req.body || {}));
}));

// GET /api/checkout/session/:id -> {paid, bookings[]}   (called when Stripe sends the customer back)
router.get('/session/:id', asyncH(async (req, res) => {
  res.set('Cache-Control', 'no-store');
  res.json(await orders.sessionView(String(req.params.id).slice(0, 200)));
}));

module.exports = router;
