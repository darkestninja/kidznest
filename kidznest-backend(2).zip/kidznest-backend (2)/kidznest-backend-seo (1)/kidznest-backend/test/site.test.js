'use strict';
// Loads the REAL website (public/index.html) in jsdom, runs its own scripts against the REAL server
// (only Stripe is faked) and drives the flows a customer would use.
process.env.DATA_DIR = require('fs').mkdtempSync(require('path').join(require('os').tmpdir(), 'kn-test-'));
process.env.ADMIN_USER = 'owner';
process.env.ADMIN_PASSWORD = 'correct-horse-battery';
process.env.BASE_URL = 'http://localhost:3999';
process.env.STRIPE_WEBHOOK_SECRET = 'whsec_test';
process.env.KN_DISABLE_LIMITS = '1';

const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const { JSDOM, VirtualConsole } = require('jsdom');
const dbm = require('../lib/db');
const U = require('../lib/util');
const stripeLib = require('../lib/stripe');

console.log = () => {}; console.warn = () => {};
const fake = { n: 0, sessions: {},
  checkout: { sessions: {
    async create(p) { const id = 'cs_test_' + (++fake.n); fake.sessions[id] = { id, url: 'https://checkout.stripe.test/' + id, status: 'open', payment_status: 'unpaid', payment_intent: 'pi_' + fake.n, params: p }; return fake.sessions[id]; },
    async retrieve(id) { return { ...fake.sessions[id] }; },
    async expire(id) { fake.sessions[id].status = 'expired'; }
  } },
  webhooks: { constructEvent: raw => JSON.parse(raw.toString()) }
};

let server, base;
const adminHdr = { Authorization: 'Basic ' + Buffer.from('owner:correct-horse-battery').toString('base64'), 'X-KN-Admin': '1', 'Content-Type': 'application/json' };
const PNG = Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==', 'base64');
const sleep = ms => new Promise(r => setTimeout(r, ms));

before(async () => {
  dbm.open(':memory:');
  stripeLib.setClient(fake);
  server = require('../server').createApp().listen(0);
  await new Promise(r => server.once('listening', r));
  base = 'http://127.0.0.1:' + server.address().port;
});
after(() => { server.close(); dbm.close(); });

async function openSite(path = '/') {
  const errors = [], alerts = [];
  const vc = new VirtualConsole();
  vc.on('jsdomError', e => { if (!/Not implemented: navigation|Could not load/.test(e.message)) errors.push(e.message); });
  const html = await (await fetch(base + path)).text();
  const dom = new JSDOM(html, {
    url: base + path, runScripts: 'dangerously', pretendToBeVisual: true, virtualConsole: vc,
    beforeParse(w) {
      w.fetch = (u, o) => fetch(new URL(u, base), o);
      // jsdom has no innerText (every real browser does); mirror it onto textContent
      Object.defineProperty(w.HTMLElement.prototype, 'innerText', { get() { return this.textContent; }, set(v) { this.textContent = v; } });
      w.scrollTo = () => {}; w.Element.prototype.scrollIntoView = () => {};
      w.alert = m => alerts.push(String(m)); w.confirm = () => true;
    }
  });
  await sleep(300); // let DOMContentLoaded handlers + first fetches finish
  return { w: dom.window, doc: dom.window.document, errors, alerts, dom };
}
const futureMonday = () => { const d = new Date(); d.setUTCDate(d.getUTCDate() + 3); while (d.getUTCDay() !== 1) d.setUTCDate(d.getUTCDate() + 1); return `${U.MONTHS[d.getUTCMonth()]} ${d.getUTCDate()}, ${d.getUTCFullYear()}`; };

test('website loads with no script errors and the API-backed bits initialise', async () => {
  const s = await openSite();
  assert.deepEqual(s.errors, []);
  assert.ok(s.doc.getElementById('sessions'));
  assert.equal(typeof s.w.confirmBook, 'function');
  s.w.showPage('sessions');
  assert.ok(s.doc.getElementById('sessions').classList.contains('active'));
  s.w.close();
});

test('?page=terms deep link opens the Terms page', async () => {
  const s = await openSite('/?page=terms');
  assert.ok(s.doc.getElementById('terms').classList.contains('active'));
  s.w.close();
});

test('reviews: submit from the form, approve in admin, shows on site with HTML escaped', async () => {
  const s = await openSite();
  s.doc.getElementById('srg').querySelector('[data-v="5"]').click();
  s.doc.getElementById('rName').value = 'Eve <b>Hacker</b>';
  s.doc.getElementById('rTitle').value = 'Great';
  s.doc.getElementById('rMsg').value = '<img src=x onerror="window.__pwned=1"> lovely place';
  await s.w.subReview();
  assert.match(s.alerts.at(-1), /submitted/i);
  const pending = await (await fetch(base + '/api/admin/reviews?filter=pending', { headers: adminHdr })).json();
  assert.equal(pending.length, 1);
  await fetch(base + `/api/admin/reviews/${pending[0].id}/approve`, { method: 'POST', headers: adminHdr, body: '{"approved":true}' });
  s.w.close();

  const s2 = await openSite();
  const grid = s2.doc.getElementById('rGrid');
  assert.match(grid.textContent, /lovely place/);
  assert.equal(grid.querySelectorAll('img').length, 0);       // injected <img> was rendered as text, not HTML
  assert.equal(grid.querySelectorAll('b').length, 0);
  assert.equal(s2.w.__pwned, undefined);
  s2.w.close();
});

test('membership: sign up and look up through the real forms', async () => {
  const s = await openSite();
  s.w.showPage('membership');
  const set = (id, v) => { s.doc.getElementById(id).value = v; };
  set('memName', 'Priya Kumar'); set('memLoc', 'Barking, London'); set('memPhone', '07700 900456'); set('memEmail', 'priya@example.com');
  await s.w.joinMembership();
  assert.deepEqual(s.alerts, []);
  const card = s.doc.getElementById('memResult');
  assert.match(card.textContent, /Priya Kumar/);
  assert.match(card.textContent, /KN-[A-Z2-9]{6}/);
  assert.match(card.textContent, /£0\.00/);
  assert.ok(!card.textContent.includes('900456'));               // phone is masked
  set('memLookupEmail', 'priya@example.com');
  await s.w.lookupMembership();
  assert.deepEqual(s.alerts, []);
  s.doc.getElementById('memLookupEmail').value = 'nobody@example.com';
  await s.w.lookupMembership();
  assert.match(s.alerts.at(-1), /No membership found/);
  s.w.close();
});

test('full customer journey: pick slot -> cart -> details -> Stripe -> confirmation -> My Bookings', async () => {
  const s = await openSite();
  const { w, doc } = s;
  const date = futureMonday();

  // choose 2 children on the Play Session card and start the booking
  w.cq('q1', 1, 8.5, 1);
  assert.equal(doc.getElementById('t1').textContent, '£17.00');
  w.startBook('Weekday Play Session', 8.5, 'q1', false, 1);
  w.bDate = date;
  w.renderTimes();
  w.goSt(2);
  await sleep(200);
  const slotEls = [...doc.querySelectorAll('#timeGr .ts')];
  assert.equal(slotEls.length, 4);                               // Monday has 4 slots
  slotEls.find(e => e.textContent.includes('1:00 PM')).click();
  w.goSt(3);
  // add one extra adult
  doc.querySelectorAll('.ex[data-price]')[0].querySelector('.qb:last-of-type').click();
  assert.equal(doc.getElementById('exTot').textContent, '£19.00');
  w.addCurrentToCart();
  assert.equal(w.cart.length, 1);
  assert.equal(doc.getElementById('cartBadge').textContent, '1');
  assert.equal(doc.getElementById('cartSubtotal').textContent, '£19.00');

  // checkout details
  w.startCheckout();
  const set = (id, v) => { doc.getElementById(id).value = v; };
  set('pFirst', 'Sarah'); set('pLast', 'Johnson'); set('pEmail', 'sarah@example.com'); set('pPhone', '07700 900123');
  doc.getElementById('tcAccept').checked = true;
  w.checkCustValid();
  assert.equal(doc.getElementById('custNxt').disabled, false);
  w.goSt(5);
  await sleep(200);
  assert.match(doc.getElementById('pSum').textContent, /19\.00/);

  // pay: the site calls the real backend, which creates a (fake) Stripe session
  await w.confirmBook();
  assert.deepEqual(s.alerts, []);
  const sid = Object.keys(fake.sessions).pop();
  const li = fake.sessions[sid].params.line_items;
  assert.equal(li.length, 1);
  assert.equal(li[0].price_data.unit_amount, 1900);
  assert.match(li[0].price_data.product_data.description, /1× Additional Supervising Adult/);
  assert.equal(fake.sessions[sid].params.customer_email, 'sarah@example.com');
  assert.equal(w.localStorage.getItem('kn_last_email'), 'sarah@example.com');

  // customer pays at Stripe and is sent back to the site
  fake.sessions[sid].status = 'complete'; fake.sessions[sid].payment_status = 'paid';
  w.history.pushState({}, '', `/?booking=success&session_id=${sid}`);
  await w.handleStripeReturn();
  assert.equal(doc.getElementById('paidAmt').textContent, '£19.00 paid');
  assert.match(doc.getElementById('confMsg').textContent, /Thank you, Sarah Johnson/);
  assert.match(doc.getElementById('confDet').textContent, /Weekday Play Session/);
  assert.match(doc.getElementById('confDet').textContent, new RegExp(date.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')));
  assert.equal(w.cart.length, 0);                                // cart emptied after a successful payment

  // My Bookings lists it
  await w.renderMyBookings();
  const list = doc.getElementById('mybkList').textContent;
  assert.match(list, /Weekday Play Session/);
  assert.match(list, /1:00 PM/);
  assert.match(list, /£19\.00/);

  // and the slot now shows 3 seats taken (2 children + 1 adult) in the booking popup
  w.startBook('Weekday Play Session', 8.5, 'q1', false, 1);
  w.bDate = date; await w.refreshAvailability();
  assert.equal(w.availCache[date]['1:00 PM'], 3);
  assert.deepEqual(s.errors, []);
  w.close();
});

test('a cancelled checkout leaves the cart intact and shows a friendly message', async () => {
  const s = await openSite('/?booking=cancelled');
  assert.match(s.alerts.at(-1), /cancelled/i);
  s.w.close();
});

test('the website surfaces server errors (full session, bad promo) as readable alerts', async () => {
  const s = await openSite();
  const { w, doc } = s;
  w.cart = [{ id: 'c1', sess: 'Weekday Play Session', price: 8.5, qty: 1, flat: false, min: 1, date: futureMonday(), time: '1:00 PM', exList: [], exTotal: 0 }];
  w.saveCart();
  const set = (id, v) => { doc.getElementById(id).value = v; };
  set('pFirst', 'Tom'); set('pLast', 'Lee'); set('pEmail', 'tom@example.com'); set('pPhone', '07700 900777'); set('pPromo', 'NOTACODE');
  await w.confirmBook();
  assert.match(s.alerts.at(-1), /isn't valid/);
  w.close();
});

test('gallery & videos: visitors can only VIEW owner uploads (no upload, comment or delete controls)', async () => {
  const up = await fetch(base + '/api/admin/media', { method: 'POST', body: PNG, headers: { ...adminHdr, 'Content-Type': 'image/png', 'X-Title': encodeURIComponent('Ball pit <img src=x>'), 'X-Description': '' } });
  assert.equal(up.status, 201);
  const s = await openSite();
  const { w, doc } = s;
  assert.deepEqual(s.errors, []);
  const html = doc.documentElement.innerHTML;
  assert.ok(!/Upload Photo|Upload Video|Share with the Community|type="file"/i.test(html));
  const g = doc.getElementById('galGrid');
  const owned = g.querySelector('.gi.up');
  assert.ok(owned, 'owner photo appears in the public gallery');
  assert.equal(g.querySelectorAll('.gcap img').length, 0);                  // title was escaped
  assert.match(doc.getElementById('vidGrid').textContent, /coming soon/i);  // no fake placeholder videos
  w.openMedia('photo', 1);
  assert.ok(doc.getElementById('mpPage').classList.contains('show'));
  assert.equal(doc.querySelectorAll('#mposts img').length, 1);
  assert.equal(doc.querySelectorAll('#mposts input, #mposts textarea, #mposts button').length, 0);
  assert.equal(typeof w.subPost, 'undefined');
  assert.equal(typeof w.deletePost, 'undefined');
  w.close();
});
