'use strict';
process.env.DATA_DIR = require('fs').mkdtempSync(require('path').join(require('os').tmpdir(), 'kn-test-'));
process.env.ADMIN_USER = 'owner';
process.env.ADMIN_PASSWORD = 'correct-horse-battery';
process.env.BASE_URL = 'http://localhost:3999';
process.env.STRIPE_WEBHOOK_SECRET = 'whsec_test';
process.env.KN_DISABLE_LIMITS = '1'; // volume of requests in this suite would trip the limiters

const { test, before, after, beforeEach } = require('node:test');
const assert = require('node:assert/strict');
const dbm = require('../lib/db');
const U = require('../lib/util');
const stripeLib = require('../lib/stripe');
const { priceCart } = require('../lib/pricing');
const orders = require('../lib/orders');
const mailer = require('../lib/mailer');

console.log = () => {}; // keep test output readable
console.warn = () => {};

// ------------------------------------------------------------ fake Stripe
const fake = {
  n: 0, sessions: {}, refundLog: [], failCreate: false,
  checkout: {
    sessions: {
      async create(p) {
        if (fake.failCreate) throw new Error('stripe down');
        const id = 'cs_test_' + (++fake.n);
        fake.sessions[id] = { id, url: 'https://checkout.stripe.test/' + id, status: 'open', payment_status: 'unpaid', payment_intent: 'pi_' + fake.n, params: p };
        return fake.sessions[id];
      },
      async retrieve(id) { const s = fake.sessions[id]; if (!s) { const e = new Error('nope'); e.code = 'resource_missing'; throw e; } return { ...s }; },
      async expire(id) { const s = fake.sessions[id]; if (s.status === 'complete') throw new Error('already complete'); s.status = 'expired'; return s; }
    }
  },
  webhooks: { constructEvent(raw, sig) { if (sig !== 'valid') throw new Error('bad sig'); return JSON.parse(raw.toString()); } },
  refunds: { async create(p, o) { fake.refundLog.push({ p, o }); return { id: 're_1' }; } }
};
const pay = id => { fake.sessions[id].status = 'complete'; fake.sessions[id].payment_status = 'paid'; };

// ------------------------------------------------------------ helpers
let server, base;
const adminHdr = { Authorization: 'Basic ' + Buffer.from('owner:correct-horse-battery').toString('base64'), 'X-KN-Admin': '1' };

async function call(method, path, body, headers = {}) {
  const r = await fetch(base + path, { method, headers: { 'Content-Type': 'application/json', ...headers }, body: body ? JSON.stringify(body) : undefined });
  let data = null; try { data = await r.json(); } catch (e) { /* not json */ }
  return { status: r.status, data };
}
const post = (p, b, h) => call('POST', p, b, h);
const get = (p, h) => call('GET', p, null, h);

// A future date on the given weekday (0=Sun) at least `minDays` ahead, as the website formats it.
function dateOn(dow, minDays = 2) {
  const d = new Date();
  d.setUTCDate(d.getUTCDate() + minDays);
  while (d.getUTCDay() !== dow) d.setUTCDate(d.getUTCDate() + 1);
  return `${U.MONTHS[d.getUTCMonth()]} ${d.getUTCDate()}, ${d.getUTCFullYear()}`;
}
const play = (over = {}) => ({ session: 'Weekday Play Session', date: dateOn(1), time: '1:00 PM', qty: 2, extraChildren: 0, flat: false, unitTotal: 17, people: 2, extras: [], ...over });
const customer = (items, over = {}) => ({ name: 'Sarah Johnson', email: 'sarah@example.com', phone: '07700 900123', promoCode: '', useReward: false, items, ...over });

before(async () => {
  dbm.open(':memory:');
  stripeLib.setClient(fake);
  const { createApp } = require('../server');
  server = createApp().listen(0);
  await new Promise(r => server.once('listening', r));
  base = 'http://127.0.0.1:' + server.address().port;
});
after(() => { server.close(); dbm.close(); });
beforeEach(() => {
  const db = dbm.get();
  ['media', 'bookings', 'holds', 'checkouts', 'members', 'reviews', 'blocked_slots', 'stripe_events'].forEach(t => db.prepare('DELETE FROM ' + t).run());
  fake.sessions = {}; fake.refundLog = []; fake.failCreate = false;
});

async function checkoutAndPay(items, over) {
  const r = await post('/api/checkout/create-session', customer(items, over));
  assert.equal(r.status, 200, JSON.stringify(r.data));
  const sid = r.data.url.split('/').pop();
  pay(sid);
  const ev = { id: 'evt_' + sid, type: 'checkout.session.completed', data: { object: { id: sid, payment_status: 'paid', payment_intent: fake.sessions[sid].payment_intent, client_reference_id: dbm.get().prepare('SELECT id FROM checkouts WHERE stripe_session_id=?').get(sid).id } } };
  const w = await call('POST', '/api/webhooks/stripe', ev, { 'stripe-signature': 'valid' });
  assert.equal(w.status, 200);
  return sid;
}

// ============================================================ pricing (pure)
test('pricing: play session, party, exclusive hire, extras', () => {
  const d = dateOn(1, 40);
  const r = priceCart({ items: [
    { session: 'Weekday Play Session', date: d, time: '1:00 PM', qty: 2, unitTotal: 17 + 2 + 3.5, extras: [{ name: 'Additional Supervising Adult', qty: 1 }, { name: 'Baby / Non-walking Child (0-12m)', qty: 1 }] },
    { session: 'Nest Party (Standard)', date: d, time: '2:30 PM', qty: 10, unitTotal: 150 },
    { session: 'Hatch Day Party (Premium)', date: d, time: '4:00 PM', qty: 12, unitTotal: 240 },
    { session: 'Exclusive Nest Hire', date: dateOn(3, 40), time: '11:30 AM', qty: null, extraChildren: 3, unitTotal: 336 }
  ] });
  assert.deepEqual(r.lines.map(l => l.subtotal), [2250, 15000, 24000, 33600]);
  assert.equal(r.lines[0].people, 4);
  assert.equal(r.lines[3].seats, 30);
  assert.equal(r.totals.total, 2250 + 15000 + 24000 + 33600);
});

test('pricing: rejects tampered totals, bad sessions, bad quantities, past dates, bad slots', () => {
  const bad = (item, re) => assert.throws(() => priceCart({ items: [item] }), re);
  bad({ ...play(), unitTotal: 1 }, /prices have just been updated/i);
  bad({ ...play(), session: 'Free Everything' }, /unknown session/i);
  bad({ ...play(), qty: 0, unitTotal: 0 }, /number of children/i);
  bad({ ...play(), qty: 31, unitTotal: 263.5 }, /number of children/i);
  bad({ ...play({ session: 'Nest Party (Standard)', qty: 9, unitTotal: 135 }) }, /number of children/i);
  bad({ ...play(), date: 'January 1, 2020' }, /past/i);
  bad({ ...play(), time: '3:45 AM' }, /not an available time/i);
  bad({ ...play(), date: 'Februarember 3, 2027' }, /invalid date/i);
  bad({ ...play(), extras: [{ name: 'Free Pony', qty: 1 }], unitTotal: 17 }, /unknown extra/i);
  bad({ ...play({ qty: 30, unitTotal: 255 }), extras: [{ name: 'Additional Supervising Adult', qty: 1 }] }, /seat limit/i);
  bad({ ...play({ date: dateOn(2), time: '10:00 AM' }) }, /not an available time/i); // Tuesday has no 10:00
  assert.throws(() => priceCart({ items: [] }), /empty/i);
});

test('pricing: promo codes follow their rules', () => {
  const far = dateOn(1, 40);
  const party = { session: 'Nest Party (Standard)', date: far, time: '1:00 PM', qty: 10, unitTotal: 150 };
  assert.equal(priceCart({ items: [party], promoCode: 'summer25' }).totals.promo, 1500);
  const near = { ...party, date: dateOn(1, 2) };
  assert.throws(() => priceCart({ items: [near], promoCode: 'SUMMER25' }), /4 weeks/);
  assert.throws(() => priceCart({ items: [play()], promoCode: 'SUMMER25' }), /party packages/);
  assert.throws(() => priceCart({ items: [play()], promoCode: 'NOPE' }), /isn't valid/);
  const fam = { ...play({ date: dateOn(2), qty: 3, unitTotal: 25.5 }) };
  assert.equal(priceCart({ items: [fam], promoCode: 'FAMILY3' }).totals.promo, 850);
  assert.throws(() => priceCart({ items: [{ ...fam, date: dateOn(4) }], promoCode: 'FAMILY3' }), /Tuesday or Wednesday/);
  assert.throws(() => priceCart({ items: [{ ...fam, qty: 2, unitTotal: 17 }], promoCode: 'FAMILY3' }), /3 or more/);
});

test('pricing: member discount, reward, never leaves a sub-30p card charge', () => {
  const member = { id: 'KN-AAAAAA', reward: 500 };
  let r = priceCart({ items: [play()], member });
  assert.equal(r.totals.member, 51);                 // 3% of £17.00
  assert.equal(r.totals.total, 1700 - 51);
  assert.equal(r.totals.earned, Math.round((1700 - 51) * 0.03));
  r = priceCart({ items: [play()], member, useReward: true });
  assert.equal(r.totals.reward, 500);
  assert.equal(r.totals.total, 1700 - 51 - 500);
  r = priceCart({ items: [play()], member: { ...member, reward: 1649 - 10 }, useReward: true }); // would leave 10p
  assert.ok(r.totals.total >= 30 || r.totals.total === 0);
  r = priceCart({ items: [play()], member: { ...member, reward: 99999 }, useReward: true });
  assert.equal(r.totals.total, 0);
});

// ============================================================ availability
test('availability: starts empty and rejects bad dates', async () => {
  const r = await get('/api/availability?date=' + encodeURIComponent(dateOn(1)));
  assert.equal(r.status, 200);
  assert.deepEqual(r.data, { booked: {} });
  assert.equal((await get('/api/availability?date=nonsense')).status, 400);
});

// ============================================================ full paid flow
test('checkout -> Stripe -> webhook -> confirmed booking, capacity and emails', async () => {
  const date = dateOn(1);
  const mails = mailer.sent.length;
  const r = await post('/api/checkout/create-session', customer([play({ date, extras: [{ name: 'Additional Supervising Adult', qty: 2 }], unitTotal: 21, people: 4 })]));
  assert.equal(r.status, 200);
  const sid = r.data.url.split('/').pop();
  const params = fake.sessions[sid].params;
  assert.equal(params.line_items[0].price_data.unit_amount, 2100);
  assert.equal(params.line_items[0].price_data.currency, 'gbp');
  assert.match(params.success_url, /booking=success&session_id=\{CHECKOUT_SESSION_ID\}/);
  assert.match(params.cancel_url, /booking=cancelled/);

  // unpaid: seats are held but the booking page says not paid yet
  assert.equal((await get('/api/checkout/session/' + sid)).data.paid, false);
  assert.equal((await get('/api/availability?date=' + encodeURIComponent(date))).data.booked['1:00 PM'], 4);

  // customer pays; webhook arrives (twice, to prove idempotency)
  pay(sid);
  const co = dbm.get().prepare('SELECT id FROM checkouts WHERE stripe_session_id=?').get(sid).id;
  const ev = { id: 'evt_1', type: 'checkout.session.completed', data: { object: { id: sid, payment_status: 'paid', payment_intent: 'pi_1', client_reference_id: co } } };
  assert.equal((await call('POST', '/api/webhooks/stripe', ev, { 'stripe-signature': 'valid' })).status, 200);
  assert.equal((await call('POST', '/api/webhooks/stripe', ev, { 'stripe-signature': 'valid' })).status, 200);
  assert.equal(dbm.get().prepare('SELECT COUNT(*) n FROM bookings').get().n, 1);

  const s = await get('/api/checkout/session/' + sid);
  assert.equal(s.data.paid, true);
  assert.equal(s.data.bookings[0].total_paid, 21);
  assert.equal(s.data.bookings[0].customer_name, 'Sarah Johnson');
  assert.equal(s.data.bookings[0].qty, 2);
  assert.equal((await get('/api/availability?date=' + encodeURIComponent(date))).data.booked['1:00 PM'], 4);
  assert.equal(mailer.sent.length - mails, 2); // customer + owner

  const mine = await get('/api/bookings/by-email/' + encodeURIComponent('SARAH@example.com'));
  assert.equal(mine.data.length, 1);
  assert.equal(mine.data[0].status, 'confirmed');
});

test('success page recovers a booking even if the webhook never arrives', async () => {
  const r = await post('/api/checkout/create-session', customer([play()]));
  const sid = r.data.url.split('/').pop();
  pay(sid); // paid at Stripe, no webhook delivered
  const s = await get('/api/checkout/session/' + sid);
  assert.equal(s.data.paid, true);
  assert.equal(s.data.bookings.length, 1);
});

test('webhook rejects bad signatures', async () => {
  const w = await call('POST', '/api/webhooks/stripe', { id: 'x', type: 'checkout.session.completed', data: { object: {} } }, { 'stripe-signature': 'forged' });
  assert.equal(w.status, 400);
});

test('capacity: 30 seats, holds block the last places, abandoned checkout frees them', async () => {
  const date = dateOn(1);
  const big = play({ date, qty: 29, unitTotal: 246.5, people: 29 });
  const a = await post('/api/checkout/create-session', customer([big]));
  assert.equal(a.status, 200);
  // someone else wants 2 seats at the same time, only 1 is left
  const b = await post('/api/checkout/create-session', customer([play({ date, qty: 2 })], { email: 'other@example.com' }));
  assert.equal(b.status, 409);
  assert.match(b.data.error, /only 1 place left/i);
  const one = await post('/api/checkout/create-session', customer([play({ date, qty: 1, unitTotal: 8.5 })], { email: 'other@example.com' }));
  assert.equal(one.status, 200);
  // first customer abandons: Stripe session expires -> webhook releases the seats
  const sid = a.data.url.split('/').pop();
  fake.sessions[sid].status = 'expired';
  const co = dbm.get().prepare('SELECT id FROM checkouts WHERE stripe_session_id=?').get(sid).id;
  await call('POST', '/api/webhooks/stripe', { id: 'evt_x', type: 'checkout.session.expired', data: { object: { id: sid, client_reference_id: co } } }, { 'stripe-signature': 'valid' });
  assert.equal((await get('/api/availability?date=' + encodeURIComponent(date))).data.booked['1:00 PM'], 1);
});

test('capacity: exclusive hire needs an empty slot and takes all 30 seats', async () => {
  const date = dateOn(3, 5);
  await checkoutAndPay([play({ date, qty: 1, unitTotal: 8.5, people: 1 })]);
  const hire = { session: 'Exclusive Nest Hire', date, time: '1:00 PM', qty: null, extraChildren: 0, flat: true, unitTotal: 300, people: 15, extras: [] };
  const r = await post('/api/checkout/create-session', customer([hire], { email: 'h@example.com' }));
  assert.equal(r.status, 409);
  const ok = await post('/api/checkout/create-session', customer([{ ...hire, time: '2:30 PM' }], { email: 'h@example.com' }));
  assert.equal(ok.status, 200);
  const avail = (await get('/api/availability?date=' + encodeURIComponent(date))).data.booked;
  assert.equal(avail['2:30 PM'], 30);
});

test('capacity: two items in one cart for the same slot are summed', async () => {
  const date = dateOn(1);
  const items = [play({ date, qty: 16, unitTotal: 136, people: 16 }), play({ date, qty: 16, unitTotal: 136, people: 16 })];
  const r = await post('/api/checkout/create-session', customer(items));
  assert.equal(r.status, 409);
});

test('owner-blocked slots show as full and cannot be booked', async () => {
  const date = dateOn(1);
  const iso = U.parseDateLabel(date).iso;
  const b = await post('/api/admin/blocks', { date: iso, time: '1:00 PM', reason: 'private event' }, adminHdr);
  assert.equal(b.status, 201);
  assert.equal((await get('/api/availability?date=' + encodeURIComponent(date))).data.booked['1:00 PM'], 30);
  const r = await post('/api/checkout/create-session', customer([play({ date })]));
  assert.equal(r.status, 409);
});

test('Stripe outage releases the held seats and returns a friendly error', async () => {
  fake.failCreate = true;
  const date = dateOn(1);
  const r = await post('/api/checkout/create-session', customer([play({ date })]));
  assert.equal(r.status, 502);
  assert.equal((await get('/api/availability?date=' + encodeURIComponent(date))).data.booked['1:00 PM'], undefined);
});

test('checkout validates customer details', async () => {
  assert.equal((await post('/api/checkout/create-session', customer([play()], { email: 'nope' }))).status, 400);
  assert.equal((await post('/api/checkout/create-session', customer([play()], { phone: 'abc' }))).status, 400);
  assert.equal((await post('/api/checkout/create-session', customer([play()], { name: '' }))).status, 400);
  assert.equal((await post('/api/checkout/create-session', customer([play()], { promoCode: 'BOGUS' }))).status, 400);
});

// ============================================================ members + rewards
test('membership: join, returning member, masked lookup, 404', async () => {
  const j = await post('/api/members/join', { name: 'Mo Ali', email: 'Mo@Example.com', phone: '07958 471236', location: 'Barking' });
  assert.equal(j.status, 201);
  assert.match(j.data.id, /^KN-[A-Z2-9]{6}$/);
  assert.equal(j.data.reward, 0);
  assert.ok(!j.data.phone.includes('471236'));          // phone is masked in responses
  const again = await post('/api/members/join', { name: 'Mohammed Ali', email: 'mo@example.com', phone: '07958 471236', location: 'Ilford' });
  assert.equal(again.data.returning, true);
  assert.equal(again.data.id, j.data.id);
  const l = await get('/api/members/lookup?email=mo@example.com');
  assert.equal(l.data.name, 'Mohammed Ali');
  assert.equal((await get('/api/members/lookup?email=ghost@example.com')).status, 404);
  assert.equal((await post('/api/members/join', { name: 'x', email: 'bad', phone: '1', location: '' })).status, 400);
});

test('rewards: earned on payment, reserved at checkout, restored if abandoned, spent when paid', async () => {
  await post('/api/members/join', { name: 'Mo Ali', email: 'mo@example.com', phone: '07958 471236', location: 'Barking' });
  const date = dateOn(1);
  await checkoutAndPay([play({ date })], { email: 'mo@example.com' });
  let m = (await get('/api/members/lookup?email=mo@example.com')).data;
  // £17.00 - 3% member discount (£0.51) = £16.49 paid; reward = 3% of that = £0.49
  assert.equal(m.reward, 0.49);
  const booking = (await get('/api/bookings/by-email/mo@example.com')).data[0];
  assert.equal(booking.total_paid, 16.49);
  assert.equal(booking.discount, 0.51);
  assert.equal(booking.reward_earned, 0.49);

  dbm.get().prepare(`UPDATE members SET reward=500 WHERE email='mo@example.com'`).run();
  const r = await post('/api/checkout/create-session', customer([play({ date, time: '2:30 PM' })], { email: 'mo@example.com', useReward: true }));
  assert.equal(r.status, 200);
  assert.equal(fake.sessions[r.data.url.split('/').pop()].params.line_items[0].price_data.unit_amount, 1649 - 500);
  assert.equal((await get('/api/members/lookup?email=mo@example.com')).data.reward, 0); // reserved
  // starting a fresh checkout abandons the old one and hands the reward back first
  const r2 = await post('/api/checkout/create-session', customer([play({ date, time: '4:00 PM' })], { email: 'mo@example.com', useReward: true }));
  assert.equal(r2.status, 200);
  assert.equal(fake.sessions[r2.data.url.split('/').pop()].params.line_items[0].price_data.unit_amount, 1649 - 500);
  const open = dbm.get().prepare(`SELECT COUNT(*) n FROM checkouts WHERE status='pending'`).get().n;
  assert.equal(open, 1);
});

test('a reward balance that covers everything confirms without Stripe', async () => {
  await post('/api/members/join', { name: 'Mo Ali', email: 'mo@example.com', phone: '07958 471236', location: 'Barking' });
  dbm.get().prepare(`UPDATE members SET reward=5000 WHERE email='mo@example.com'`).run();
  const r = await post('/api/checkout/create-session', customer([play()], { email: 'mo@example.com', useReward: true }));
  assert.equal(r.status, 200);
  assert.match(r.data.url, /booking=success&session_id=free_/);
  const sid = new URL(r.data.url).searchParams.get('session_id');
  const s = await get('/api/checkout/session/' + sid);
  assert.equal(s.data.paid, true);
  assert.equal(s.data.bookings[0].total_paid, 0);
  assert.equal(Object.keys(fake.sessions).length, 0);
  assert.equal((await get('/api/members/lookup?email=mo@example.com')).data.reward.toFixed(2), '33.51');
});

// ============================================================ reviews
test('reviews: held for approval, then published newest-first', async () => {
  assert.equal((await post('/api/reviews', { name: 'Ann', rating: 5, text: '<script>alert(1)</script> Great place' })).status, 201);
  assert.equal((await post('/api/reviews', { name: 'Bob', rating: 4, text: 'Lovely staff here' })).status, 201);
  assert.equal((await get('/api/reviews')).data.length, 0);
  const pending = (await get('/api/admin/reviews?filter=pending', adminHdr)).data;
  assert.equal(pending.length, 2);
  for (const r of pending) await post(`/api/admin/reviews/${r.id}/approve`, { approved: true }, adminHdr);
  const pub = (await get('/api/reviews')).data;
  assert.equal(pub.length, 2);
  assert.equal(pub[0].name, 'Bob');
  assert.equal((await post('/api/reviews', { name: 'x', rating: 9, text: 'too many stars' })).status, 400);
  assert.equal((await post('/api/reviews', { name: '', rating: 5, text: 'no name given' })).status, 400);
});

// ============================================================ admin
test('admin: requires credentials and the CSRF header', async () => {
  assert.equal((await get('/api/admin/stats')).status, 401);
  assert.equal((await get('/api/admin/stats', { Authorization: 'Basic ' + Buffer.from('owner:wrong').toString('base64') })).status, 401);
  assert.equal((await get('/api/admin/stats', adminHdr)).status, 200);
  const noHdr = { Authorization: adminHdr.Authorization };
  assert.equal((await post('/api/admin/blocks', { date: '2030-01-01' }, noHdr)).status, 403);
  const page = await fetch(base + '/admin');
  assert.equal(page.status, 401);
  const ok = await fetch(base + '/admin/', { headers: { Authorization: adminHdr.Authorization } });
  assert.equal(ok.status, 200);
  assert.match(await ok.text(), /Kidz Nest Admin/);
});

test('admin: cancel + refund through Stripe frees the seats and reverses rewards', async () => {
  await post('/api/members/join', { name: 'Mo Ali', email: 'mo@example.com', phone: '07958 471236', location: 'Barking' });
  const date = dateOn(1);
  await checkoutAndPay([play({ date })], { email: 'mo@example.com' });
  const list = (await get('/api/admin/bookings', adminHdr)).data;
  assert.equal(list.length, 1);
  const id = list[0].id;
  const c = await post(`/api/admin/bookings/${id}/cancel`, { refund: true, note: 'illness' }, adminHdr);
  assert.equal(c.status, 200);
  assert.equal(c.data.refunded, 16.49);
  assert.equal(fake.refundLog[0].p.amount, 1649);
  assert.equal(fake.refundLog[0].p.payment_intent.startsWith('pi_'), true);
  assert.equal((await get('/api/availability?date=' + encodeURIComponent(date))).data.booked['1:00 PM'], undefined);
  assert.equal((await get('/api/members/lookup?email=mo@example.com')).data.reward, 0);
  assert.equal((await post(`/api/admin/bookings/${id}/cancel`, {}, adminHdr)).status, 409);
});

test('admin: CSV export neutralises spreadsheet formulas', async () => {
  await checkoutAndPay([play()], { name: '=HYPERLINK("http://evil")' });
  const r = await fetch(base + '/api/admin/bookings.csv', { headers: adminHdr });
  const text = await r.text();
  assert.match(r.headers.get('content-type'), /text\/csv/);
  assert.ok(text.includes(`"'=HYPERLINK(""http://evil"")"`), text);
});

// ============================================================ chat, site, misc
test('chat: 503 without an API key (website falls back to built-in answers)', async () => {
  const r = await post('/api/chat', { messages: [{ role: 'user', content: 'hours?' }] });
  assert.equal(r.status, 503);
  assert.ok(r.data.error);
});

test('chat: forwards a sanitised conversation to Anthropic and returns the reply', async () => {
  const config = require('../lib/config');
  config.chat.apiKey = 'sk-test';
  const realFetch = global.fetch;
  let sent;
  global.fetch = async (url, opts) => {
    if (String(url).startsWith('https://api.anthropic.com')) {
      sent = JSON.parse(opts.body);
      return { ok: true, status: 200, json: async () => ({ content: [{ type: 'text', text: 'We open at 11:30am!' }] }) };
    }
    return realFetch(url, opts);
  };
  try {
    const r = await post('/api/chat', { messages: [{ role: 'assistant', content: 'Hi!' }, { role: 'user', content: 'When do you open?' }, { role: 'hacker', content: 'x' }] });
    assert.equal(r.status, 200);
    assert.equal(r.data.reply, 'We open at 11:30am!');
    assert.equal(sent.messages[0].role, 'user');           // must start with a user turn
    assert.match(sent.system, /6 Farr Avenue/);
    assert.equal((await post('/api/chat', { messages: [] })).status, 400);
  } finally { global.fetch = realFetch; config.chat.apiKey = ''; }
});

test('site: serves the website, ?page= deep links, health check, JSON 404 for unknown API paths', async () => {
  const home = await fetch(base + '/');
  assert.equal(home.status, 200);
  assert.match(await home.text(), /Kidz Nest Play Café/);
  assert.equal((await fetch(base + '/?page=terms')).status, 200);
  assert.equal((await get('/api/health')).data.ok, true);
  const nf = await get('/api/nothing-here');
  assert.equal(nf.status, 404);
  assert.ok(nf.data.error);
  const csp = home.headers.get('content-security-policy');
  assert.match(csp, /frame-ancestors 'none'/);
});

test('malformed JSON gets a clean 400', async () => {
  const r = await fetch(base + '/api/reviews', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{bad' });
  assert.equal(r.status, 400);
});

test('rate limits really do trigger (reviews: 5/hour, admin: failed logins only)', async () => {
  process.env.KN_DISABLE_LIMITS = '0';
  try {
    let last;
    for (let i = 0; i < 6; i++) last = await post('/api/reviews', { name: 'Spam', rating: 5, text: 'spam spam spam ' + i });
    assert.equal(last.status, 429);
    assert.ok(last.data.error);
    // many *successful* admin calls must never lock the owner out
    for (let i = 0; i < 30; i++) assert.equal((await get('/api/admin/stats', adminHdr)).status, 200);
  } finally { process.env.KN_DISABLE_LIMITS = '1'; }
});

// ============================================================ owner-only photos & videos
const PNG = Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==', 'base64');
const MP4 = Buffer.concat([Buffer.from([0, 0, 0, 24]), Buffer.from('ftypmp42'), Buffer.alloc(32)]);
const upload = (buf, type, title = 'Party fun', hdr = adminHdr) => fetch(base + '/api/admin/media', {
  method: 'POST', body: buf,
  headers: { ...hdr, 'Content-Type': type, 'X-Title': encodeURIComponent(title), 'X-Description': encodeURIComponent('A lovely day') }
});

test('media: only the owner can upload; the public can only view', async () => {
  // visitors / anyone without admin credentials cannot upload, list-manage or delete
  const noAuth = await fetch(base + '/api/admin/media', { method: 'POST', body: PNG, headers: { 'Content-Type': 'image/png', 'X-Title': 'x', 'X-KN-Admin': '1' } });
  assert.equal(noAuth.status, 401);
  assert.equal((await fetch(base + '/api/admin/media/1', { method: 'DELETE', headers: { 'X-KN-Admin': '1' } })).status, 401);
  assert.equal((await upload(PNG, 'image/png', 'x', { Authorization: adminHdr.Authorization })).status, 403); // missing CSRF header

  const up = await upload(PNG, 'image/png', 'Ball pit <b>fun</b>');
  assert.equal(up.status, 201);
  const vid = await upload(MP4, 'video/mp4', 'Tour');
  assert.equal(vid.status, 201);

  const pub = await get('/api/media');                         // no credentials needed to VIEW
  assert.equal(pub.status, 200);
  assert.equal(pub.data.length, 2);
  assert.equal(pub.data[0].type, 'video');
  assert.equal(pub.data[1].title, 'Ball pit <b>fun</b>');
  assert.match(pub.data[1].url, /^\/media\/[0-9a-f-]+\.png$/);
  const file = await fetch(base + pub.data[1].url);
  assert.equal(file.status, 200);
  assert.equal(file.headers.get('content-type'), 'image/png');
  assert.equal(file.headers.get('x-content-type-options'), 'nosniff');
  assert.equal(Buffer.from(await file.arrayBuffer()).equals(PNG), true);
  const range = await fetch(base + pub.data[0].url, { headers: { Range: 'bytes=0-9' } });
  assert.equal(range.status, 206);                             // video seeking works

  await call('DELETE', '/api/admin/media/' + pub.data[1].id, null, adminHdr);
  assert.equal((await get('/api/media')).data.length, 1);
  assert.equal((await fetch(base + pub.data[1].url)).status, 404);
});

test('media: rejects fake, oversized and wrongly-labelled files', async () => {
  assert.equal((await upload(Buffer.from('<script>alert(1)</script>'), 'image/png')).status, 400); // text pretending to be a PNG
  assert.equal((await upload(PNG, 'video/mp4')).status, 400);                                      // photo labelled as video
  assert.equal((await upload(PNG, 'application/pdf')).status, 415);
  assert.equal((await upload(PNG, 'image/png', '   ')).status, 400);                               // title required
  const big = Buffer.alloc(16 * 1024 * 1024); PNG.copy(big);
  assert.equal((await upload(big, 'image/png')).status, 413);                                      // photos max 15 MB
  assert.equal((await get('/api/media')).data.length, 0);
  const left = require('fs').readdirSync(require('path').join(process.env.DATA_DIR, 'media')).filter(f => f.endsWith('.part'));
  assert.deepEqual(left, []);                                                                       // no half-uploaded junk left
});
