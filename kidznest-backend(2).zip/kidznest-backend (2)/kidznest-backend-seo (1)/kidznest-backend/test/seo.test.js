'use strict';
process.env.DATA_DIR = require('fs').mkdtempSync(require('path').join(require('os').tmpdir(), 'kn-seo-'));
process.env.ADMIN_PASSWORD = 'correct-horse-battery';
process.env.BASE_URL = 'http://localhost:3999';
process.env.STRIPE_WEBHOOK_SECRET = 'whsec_test';
process.env.KN_DISABLE_LIMITS = '1';

const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs'), path = require('path');
const dbm = require('../lib/db');
const seo = require('../lib/seo');

let server, base;
before(async () => {
  dbm.open(':memory:');
  server = require('../server').createApp().listen(0);
  await new Promise(r => server.once('listening', r));
  base = 'http://127.0.0.1:' + server.address().port;
});
after(() => { server.close(); dbm.close(); });
const get = (p, o) => fetch(base + p, { redirect: 'manual', ...o });
const ld = html => JSON.parse(html.match(/<script type="application\/ld\+json">([\s\S]*?)<\/script>/)[1]);

test('every page has its own title, description, canonical, one visible h1 and the right section active', async () => {
  const titles = new Set();
  for (const p of seo.PAGES) {
    const r = await get(p.path); const html = await r.text();
    assert.equal(r.status, 200, p.path);
    const title = html.match(/<title>([^<]*)<\/title>/)[1];
    titles.add(title);
    assert.match(html, new RegExp(`<link rel="canonical" href="${seo.SITE_URL}${p.path === '/' ? '/' : p.path}">`));
    assert.equal((html.match(/<meta name="description"/g) || []).length, 1, p.path);
    assert.equal((html.match(/<title>/g) || []).length, 1, p.path);
    assert.match(html, p.noindex ? /content="noindex,follow"/ : /content="index,follow,/);
    const active = [...html.matchAll(/<(?:div|section)[^>]*class="([^"]*)"[^>]*data-page="([^"]+)"/g)].filter(m => /\bactive\b/.test(m[1])).map(m => m[2]);
    assert.ok(active.length && active.every(k => k === p.key), `${p.path} active=${active}`);
    assert.ok(!/javascript:void\(0\)" class="logo"/.test(html));
  }
  assert.equal(titles.size, seo.PAGES.length, 'titles must be unique');
});

test('navigation links are real, crawlable hrefs', async () => {
  const html = await (await get('/')).text();
  for (const p of ['/about', '/sessions', '/offers', '/gallery', '/reviews', '/contact'])
    assert.ok(html.includes(`<a href="${p}"`), p);
  assert.ok(!/<nav>[\s\S]*?<\/nav>/.test(html) || !/<nav>[\s\S]*?javascript:void/.test(html.match(/<nav>[\s\S]*?<\/nav>/)[0]));
});

test('robots.txt, sitemap.xml, llms.txt, manifest', async () => {
  const robots = await (await get('/robots.txt')).text();
  assert.match(robots, /User-agent: \*/); assert.match(robots, /Disallow: \/admin/); assert.match(robots, /GPTBot/); assert.match(robots, /ClaudeBot/);
  assert.match(robots, new RegExp(`Sitemap: ${seo.SITE_URL}/sitemap.xml`));
  const sm = await (await get('/sitemap.xml')).text();
  assert.ok(sm.includes(`<loc>${seo.SITE_URL}/sessions</loc>`)); assert.ok(!sm.includes('my-bookings')); assert.match(sm, /<image:loc>/);
  const llms = await (await get('/llms.txt')).text();
  assert.match(llms, /^# Kidz Nest Play Café/); assert.match(llms, /£8\.50 per child/); assert.match(llms, /IG11 0NZ/);
  assert.equal(JSON.parse(await (await get('/manifest.webmanifest')).text()).short_name, 'Kidz Nest');
});

test('JSON-LD parses and uses valid, matching data', async () => {
  const home = ld(await (await get('/')).text());
  const types = home['@graph'].map(n => [].concat(n['@type']).join());
  assert.ok(types.includes('WebSite')); assert.ok(types.some(t => t.includes('LocalBusiness')));
  const biz = home['@graph'].find(n => String(n['@type']).includes('LocalBusiness'));
  assert.equal(biz.address.postalCode, 'IG11 0NZ'); assert.equal(biz.openingHoursSpecification.length, 2);
  assert.ok(!JSON.stringify(home).includes('aggregateRating'), 'no unverified rating markup');
  const contact = ld(await (await get('/contact')).text());
  const faq = contact['@graph'].find(n => n['@type'] === 'FAQPage');
  assert.ok(faq && faq.mainEntity.length >= 6);
  assert.ok(faq.mainEntity.every(q => q.name && q.acceptedAnswer.text && !/&\w+;/.test(q.acceptedAnswer.text)));
  const sessions = ld(await (await get('/sessions')).text());
  const cat = sessions['@graph'].find(n => n['@type'] === 'OfferCatalog');
  assert.equal(cat.itemListElement[0].price, '8.50');
  assert.ok(sessions['@graph'].some(n => n['@type'] === 'BreadcrumbList'));
});

test('old ?page= links 301 to clean URLs; Stripe return links are untouched; unknown URLs are real 404s', async () => {
  const r = await get('/?page=sessions'); assert.equal(r.status, 301); assert.equal(r.headers.get('location'), '/sessions');
  assert.equal((await get('/?booking=cancelled')).status, 200);
  assert.equal((await get('/sessions/')).status, 301);
  assert.equal((await get('/index.html')).status, 301);
  const nf = await get('/this-does-not-exist'); assert.equal(nf.status, 404); assert.match(await nf.text(), /noindex/);
  assert.equal((await get('/api/health')).headers.get('x-robots-tag'), 'noindex, nofollow');
});

test('speed: no inline images, small HTML, long-cached hashed images, compressed', async () => {
  const src = fs.readFileSync(path.join(__dirname, '..', 'public', 'index.html'), 'utf8');
  assert.ok(!/base64,/.test(src), 'no base64 blobs in the page');
  assert.ok(src.length < 250 * 1024, 'html size ' + src.length);
  const imgs = [...src.matchAll(/src="\/?(img\/[^"]+)"/g)].map(m => '/' + m[1]);
  assert.ok(imgs.length >= 7);
  for (const i of imgs) assert.ok(fs.existsSync(path.join(__dirname, '..', 'public', i)), i);
  assert.ok(/<img [^>]*width="\d+" height="\d+"[^>]*loading="lazy"/.test(src), 'dimensions + lazy loading');
  const r = await get(imgs[0]); assert.match(r.headers.get('cache-control'), /max-age=31536000/);
  const gz = await fetch(base + '/', { headers: { 'Accept-Encoding': 'gzip' } }); assert.equal(gz.headers.get('content-encoding'), 'gzip');
});
