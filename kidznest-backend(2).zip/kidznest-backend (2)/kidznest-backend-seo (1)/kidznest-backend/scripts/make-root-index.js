'use strict';
// Writes ./index.html (next to server.js) so the site can be opened by double-click, no server needed.
// Booking/payment/reviews still need the server (npm start); the pages, photos and navigation work.
// Edit the website in public/index.html, then run:  npm run preview
const fs = require('fs'), path = require('path');
const root = path.join(__dirname, '..');
let h = fs.readFileSync(path.join(root, 'public', 'index.html'), 'utf8');
h = h.replace(/(["(, ])img\//g, '$1public/img/')
     .replace(/href="\/(favicon[^"]*|apple-touch-icon\.png)"/g, 'href="public/$1"')
     .replace('<link rel="manifest" href="/manifest.webmanifest">\n', '');
fs.writeFileSync(path.join(root, 'index.html'), h);
console.log('index.html written');
