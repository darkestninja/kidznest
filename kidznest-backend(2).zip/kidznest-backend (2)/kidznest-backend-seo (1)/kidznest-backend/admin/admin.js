'use strict';
(function () {
  var $ = function (s) { return document.querySelector(s); };
  var esc = function (t) { return String(t == null ? '' : t).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); };
  var gbp = function (n) { return '£' + Number(n || 0).toFixed(2); };
  var tab = 'bookings';

  function toast(m) { var t = $('#toast'); t.textContent = m; t.style.display = 'block'; clearTimeout(toast.h); toast.h = setTimeout(function () { t.style.display = 'none'; }, 3500); }
  function api(path, opts) {
    opts = opts || {};
    var o = { method: opts.method || 'GET', headers: { 'X-KN-Admin': '1' } };
    if (opts.body) { o.headers['Content-Type'] = 'application/json'; o.body = JSON.stringify(opts.body); }
    return fetch('/api/admin' + path, o).then(function (r) {
      return r.json().catch(function () { return {}; }).then(function (d) { if (!r.ok) throw new Error(d.error || 'Request failed'); return d; });
    });
  }

  function stats() {
    api('/stats').then(function (s) {
      $('#stats').innerHTML =
        '<div class="card"><small>Bookings today</small><b>' + s.bookingsToday.n + '</b><small>' + s.bookingsToday.p + ' people</small></div>' +
        '<div class="card"><small>Upcoming bookings</small><b>' + s.upcoming.n + '</b><small>' + gbp(s.upcoming.revenue) + ' taken</small></div>' +
        '<div class="card"><small>Net revenue (all time)</small><b>' + gbp(s.revenueAll) + '</b></div>' +
        '<div class="card"><small>Members</small><b>' + s.members + '</b></div>' +
        '<div class="card"><small>Reviews to approve</small><b>' + s.pendingReviews + '</b></div>';
      var w = [];
      if (!s.stripeConfigured) w.push('Stripe is not configured: customers cannot pay yet.');
      if (!s.mailConfigured) w.push('Email (SMTP) is not configured: confirmation emails are not being sent.');
      if (!s.chatConfigured) w.push('AI chat key is not set: the chat widget uses its built-in answers.');
      $('#warn').innerHTML = w.length ? '<div class="warn">⚠️ ' + w.map(esc).join('<br>⚠️ ') + '</div>' : '';
    }).catch(function (e) { toast(e.message); });
  }

  function table(head, rows) {
    return '<div class="wrap"><table><thead><tr>' + head.map(function (h) { return '<th>' + esc(h) + '</th>'; }).join('') + '</tr></thead><tbody>' +
      (rows.length ? rows.join('') : '<tr><td colspan="' + head.length + '">Nothing here yet.</td></tr>') + '</tbody></table></div>';
  }

  // ---------- bookings
  var bq = { q: '', status: '', from: '', to: '' };
  function bookings() {
    var qs = Object.keys(bq).filter(function (k) { return bq[k]; }).map(function (k) { return k + '=' + encodeURIComponent(bq[k]); }).join('&');
    api('/bookings?' + qs).then(function (list) {
      $('#view').innerHTML =
        '<div class="bar"><input id="fq" placeholder="Search name, email, phone" value="' + esc(bq.q) + '">' +
        '<select id="fs"><option value="">All</option><option value="confirmed">Confirmed</option><option value="cancelled">Cancelled</option></select>' +
        '<label>From <input type="date" id="ff" value="' + esc(bq.from) + '"></label><label>To <input type="date" id="ft" value="' + esc(bq.to) + '"></label>' +
        '<button class="b" id="go">Filter</button><a class="b" style="text-decoration:none;padding:8px 12px;border-radius:8px;background:#2ECC71;color:#fff" href="/api/admin/bookings.csv?' + qs + '" id="csv">Export CSV</a></div>' +
        table(['Date', 'Time', 'Session', 'Who', 'People', 'Paid', 'Status', ''], list.map(function (b) {
          var extra = b.extras.map(function (e) { return e.qty + '× ' + e.name; }).join(', ');
          return '<tr><td>' + esc(b.date) + '</td><td>' + esc(b.time) + '</td><td><b>' + esc(b.session) + '</b><br><small>' + esc(b.children) + ' children' + (extra ? ' + ' + esc(extra) : '') + (b.promo_code ? ' · code ' + esc(b.promo_code) : '') + '</small></td>' +
            '<td>' + esc(b.name) + '<br><small>' + esc(b.email) + '<br>' + esc(b.phone) + '</small></td><td>' + b.people + '</td>' +
            '<td>' + gbp(b.total_paid) + (b.refunded ? '<br><small>refunded ' + gbp(b.refunded) + '</small>' : '') + '</td>' +
            '<td><span class="tag ' + esc(b.status) + '">' + esc(b.status) + '</span>' + (b.note ? '<br><small>' + esc(b.note) + '</small>' : '') + '</td>' +
            '<td>' + (b.status === 'confirmed' ? '<button class="b r" data-cancel="' + b.id + '" data-paid="' + b.total_paid + '">Cancel</button>' : '') + '</td></tr>';
        }));
      $('#fs').value = bq.status;
      $('#go').onclick = function () { bq = { q: $('#fq').value, status: $('#fs').value, from: $('#ff').value, to: $('#ft').value }; bookings(); };
      document.querySelectorAll('[data-cancel]').forEach(function (btn) {
        btn.onclick = function () {
          var paid = Number(btn.dataset.paid);
          var refund = paid > 0 && confirm('Cancel this booking.\n\nPress OK to ALSO refund ' + gbp(paid) + ' to the customer\'s card, or Cancel to cancel WITHOUT a refund.');
          if (!refund && !confirm('Cancel this booking without refunding the customer?')) return;
          var note = prompt('Optional note (e.g. reason for cancelling):') || '';
          api('/bookings/' + btn.dataset.cancel + '/cancel', { method: 'POST', body: { refund: refund, note: note } })
            .then(function (r) { toast(r.refunded ? 'Cancelled and refunded ' + gbp(r.refunded) : 'Cancelled'); bookings(); stats(); })
            .catch(function (e) { toast(e.message); });
        };
      });
    }).catch(function (e) { toast(e.message); });
  }

  // ---------- members
  function members() {
    api('/members').then(function (list) {
      $('#view').innerHTML = table(['ID', 'Name', 'Email', 'Phone', 'Location', 'Reward', 'Joined', ''], list.map(function (m) {
        return '<tr><td>' + esc(m.id) + '</td><td>' + esc(m.name) + '</td><td>' + esc(m.email) + '</td><td>' + esc(m.phone) + '</td><td>' + esc(m.location) + '</td><td>' + gbp(m.reward) + '</td><td>' + esc(m.created_at.slice(0, 10)) + '</td>' +
          '<td><button class="b s" data-adj="' + esc(m.id) + '">Adjust reward</button> <button class="b r" data-del="' + esc(m.id) + '">Delete</button></td></tr>';
      }));
      document.querySelectorAll('[data-adj]').forEach(function (b) { b.onclick = function () {
        var v = prompt('Add or remove reward in £ (e.g. 5 or -2.50):'); if (v === null) return;
        api('/members/' + b.dataset.adj + '/reward', { method: 'POST', body: { amount: v } }).then(function () { toast('Reward updated'); members(); }).catch(function (e) { toast(e.message); });
      }; });
      document.querySelectorAll('[data-del]').forEach(function (b) { b.onclick = function () {
        if (!confirm('Delete this member? Their past bookings are kept.')) return;
        api('/members/' + b.dataset.del, { method: 'DELETE' }).then(function () { toast('Deleted'); members(); stats(); }).catch(function (e) { toast(e.message); });
      }; });
    }).catch(function (e) { toast(e.message); });
  }

  // ---------- reviews
  function reviews() {
    api('/reviews').then(function (list) {
      $('#view').innerHTML = table(['When', 'Name', 'Rating', 'Review', 'Status', ''], list.map(function (r) {
        return '<tr><td>' + esc(r.created_at.slice(0, 10)) + '</td><td>' + esc(r.name) + '</td><td>' + '★'.repeat(r.rating) + '</td><td style="max-width:440px">' + esc(r.text) + '</td>' +
          '<td><span class="tag ' + (r.approved ? 'confirmed' : 'cancelled') + '">' + (r.approved ? 'Published' : 'Pending') + '</span></td>' +
          '<td>' + (r.approved ? '<button class="b s" data-un="' + r.id + '">Unpublish</button>' : '<button class="b g" data-ap="' + r.id + '">Approve</button>') + ' <button class="b r" data-rd="' + r.id + '">Delete</button></td></tr>';
      }));
      document.querySelectorAll('[data-ap]').forEach(function (b) { b.onclick = function () { api('/reviews/' + b.dataset.ap + '/approve', { method: 'POST', body: { approved: true } }).then(function () { reviews(); stats(); }); }; });
      document.querySelectorAll('[data-un]').forEach(function (b) { b.onclick = function () { api('/reviews/' + b.dataset.un + '/approve', { method: 'POST', body: { approved: false } }).then(function () { reviews(); stats(); }); }; });
      document.querySelectorAll('[data-rd]').forEach(function (b) { b.onclick = function () { if (confirm('Delete this review?')) api('/reviews/' + b.dataset.rd, { method: 'DELETE' }).then(function () { reviews(); stats(); }); }; });
    }).catch(function (e) { toast(e.message); });
  }

  // ---------- photos & videos (owner uploads; the public can only view)
  function media() {
    api('/media').then(function (list) {
      $('#view').innerHTML =
        '<div class="card" style="margin-bottom:16px"><b style="font-size:1.05rem">Upload a photo or video</b>' +
        '<p style="font-size:.85rem;color:#7F8C8D;margin:6px 0 12px">Photos: JPG, PNG, WebP or GIF up to 15 MB. Videos: MP4, MOV or WebM up to 50 MB. Uploads appear straight away on the public Gallery / Videos pages. Visitors can only view them.</p>' +
        '<div class="bar"><input type="file" id="mf" accept="image/*,video/mp4,video/quicktime,video/webm"><input id="mt" placeholder="Title (required)" size="28" maxlength="100"><input id="md" placeholder="Short description (optional)" size="36" maxlength="300"><button class="b" id="mu">Upload</button></div>' +
        '<div id="mp" style="font-size:.85rem;margin-top:6px"></div></div>' +
        '<div class="cards" id="mg">' + (list.length ? list.map(function (m) {
          var thumb = m.type === 'video' ? '<video src="' + esc(m.url) + '#t=0.1" preload="metadata" muted style="width:100%;height:140px;object-fit:cover;border-radius:8px;background:#000"></video>'
            : '<img src="' + esc(m.url) + '" alt="" style="width:100%;height:140px;object-fit:cover;border-radius:8px">';
          return '<div class="card">' + thumb + '<div style="margin-top:8px"><b style="font-size:.95rem">' + esc(m.title) + '</b><small>' + (m.type === 'video' ? '🎬 Video' : '📸 Photo') + ' · ' + esc(m.created_at.slice(0, 10)) + '</small>' +
            (m.description ? '<small>' + esc(m.description) + '</small>' : '') + '</div><button class="b r" style="margin-top:8px" data-dm="' + m.id + '">Delete</button></div>';
        }).join('') : '<p>No photos or videos yet.</p>') + '</div>';
      $('#mu').onclick = function () {
        var f = $('#mf').files[0], t = $('#mt').value.trim();
        if (!f) { toast('Choose a file first.'); return; }
        if (!t) { toast('Please add a title.'); return; }
        var xhr = new XMLHttpRequest();
        xhr.open('POST', '/api/admin/media');
        xhr.setRequestHeader('X-KN-Admin', '1');
        xhr.setRequestHeader('Content-Type', f.type || 'application/octet-stream');
        xhr.setRequestHeader('X-Title', encodeURIComponent(t));
        xhr.setRequestHeader('X-Description', encodeURIComponent($('#md').value.trim()));
        xhr.upload.onprogress = function (e) { if (e.lengthComputable) $('#mp').textContent = 'Uploading… ' + Math.round(e.loaded / e.total * 100) + '%'; };
        xhr.onload = function () {
          var d = {}; try { d = JSON.parse(xhr.responseText); } catch (e) {}
          if (xhr.status === 201) { toast('Uploaded ✓'); media(); } else { $('#mp').textContent = ''; toast(d.error || 'Upload failed'); }
        };
        xhr.onerror = function () { toast('Upload failed. Check your connection.'); };
        $('#mu').disabled = true; $('#mp').textContent = 'Uploading… 0%';
        xhr.send(f);
      };
      document.querySelectorAll('[data-dm]').forEach(function (b) { b.onclick = function () {
        if (confirm('Delete this from the website?')) api('/media/' + b.dataset.dm, { method: 'DELETE' }).then(function () { toast('Deleted'); media(); }).catch(function (e) { toast(e.message); });
      }; });
    }).catch(function (e) { toast(e.message); });
  }

  // ---------- closures
  function blocks() {
    api('/blocks').then(function (list) {
      $('#view').innerHTML = '<div class="bar"><input type="date" id="bd"><select id="bt"><option value="">Whole day</option></select><input id="br" placeholder="Reason (private)" size="26"><button class="b" id="badd">Block</button></div>' +
        '<p style="font-size:.85rem;color:#7F8C8D">Blocked times show as "Full" on the website. Existing bookings are not cancelled.</p>' +
        table(['Date', 'Time', 'Reason', ''], list.map(function (b) {
          return '<tr><td>' + esc(b.date_iso) + '</td><td>' + esc(b.time_label || 'Whole day') + '</td><td>' + esc(b.reason) + '</td><td><button class="b r" data-rb="' + b.id + '">Remove</button></td></tr>';
        }));
      $('#bd').onchange = function () {
        api('/slots?date=' + $('#bd').value).then(function (s) { $('#bt').innerHTML = '<option value="">Whole day</option>' + s.map(function (t) { return '<option>' + esc(t) + '</option>'; }).join(''); });
      };
      $('#badd').onclick = function () {
        api('/blocks', { method: 'POST', body: { date: $('#bd').value, time: $('#bt').value, reason: $('#br').value } }).then(function () { toast('Blocked'); blocks(); }).catch(function (e) { toast(e.message); });
      };
      document.querySelectorAll('[data-rb]').forEach(function (b) { b.onclick = function () { api('/blocks/' + b.dataset.rb, { method: 'DELETE' }).then(blocks); }; });
    }).catch(function (e) { toast(e.message); });
  }

  var views = { bookings: bookings, members: members, reviews: reviews, media: media, blocks: blocks };
  document.querySelectorAll('#nav button').forEach(function (b) {
    b.onclick = function () {
      document.querySelectorAll('#nav button').forEach(function (x) { x.classList.remove('on'); });
      b.classList.add('on'); tab = b.dataset.t; views[tab]();
    };
  });
  stats(); bookings();
})();
